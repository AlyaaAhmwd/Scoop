<?php

XTS\Import\Import::get_instance()->render();

